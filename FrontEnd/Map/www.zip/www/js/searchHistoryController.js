var searchHistoryModule = angular.module('searchHistory.controllers', ['ionic']);

searchHistoryModule.controller('SearchHistoryCtrl', function ($scope, $state, $ionicHistory, $http) {

  $scope.searchHistoryList = new Array();

  console.log("请求进入");

  // 返回上一层
  $scope.backToMap = function () {
    $ionicHistory.goBack();
  };
  $scope.showMainMap = function () {
    $state.go('mainmap');
  };
  $scope.jumpToSceneDetail = function (IdOfScene) {
    console.log("id before jump" + IdOfScene);
    $scope.popover.hide();
    $state.go("sceneDetail", {IdOfScene: IdOfScene});
  };

  console.log(searchHistoryNumI);
  //搜索历史景观列表
  if (searchHistoryNumI > 0) {
    $http({
      method: 'POST',
      url: "http://localhost:8080/server/scene/detail",
      params: {"sceneid": searchHistoryListId[0]},
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS, PUT, DELETE',
        'Access-Control-Allow-Headers': 'X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method',
        'Access-Control-Allow-Max-Age': '100'
      }
    }).success(function (response) {
      console.log(JSON.stringify(response));

      $scope.searchHistoryList[0] = {
        id: response.scene.sceneId,
        name: response.scene.sceneName,
        score: response.scene.sceneScore,
        star: response.scene.sceneFavor,
        come: response.scene.sceneVisited,
        wish: response.sceneWish,
        show: response.scene.sceneScore,
        sortType: "score"
      };

      //$scope.$apply();
    })
      .error(function (error) {
        console.log(error);
        $state.reload('login');
      });
  }

  if (searchHistoryNumI > 1) {
    $http({
      method: 'POST',
      url: "http://localhost:8080/server/scene/detail",
      params: {"sceneid": searchHistoryListId[1]},
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS, PUT, DELETE',
        'Access-Control-Allow-Headers': 'X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method',
        'Access-Control-Allow-Max-Age': '100'
      }
    }).success(function (response) {
      console.log(JSON.stringify(response));

      $scope.searchHistoryList[1] = {
        id: response.scene.sceneId,
        name: response.scene.sceneName,
        score: response.scene.sceneScore,
        star: response.scene.sceneFavor,
        come: response.scene.sceneVisited,
        wish: response.sceneWish,
        show: response.scene.sceneScore,
        sortType: "score"
      };
    })
      .error(function (error) {
        console.log(error);
        $state.reload('login');
      });
  }

  if (searchHistoryNumI > 2) {
    $http({
      method: 'POST',
      url: "http://localhost:8080/server/scene/detail",
      params: {"sceneid": searchHistoryListId[2]},
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS, PUT, DELETE',
        'Access-Control-Allow-Headers': 'X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method',
        'Access-Control-Allow-Max-Age': '100'
      }
    }).success(function (response) {
      console.log(JSON.stringify(response));

      $scope.searchHistoryList[2] = {
        id: response.scene.sceneId,
        name: response.scene.sceneName,
        score: response.scene.sceneScore,
        star: response.scene.sceneFavor,
        come: response.scene.sceneVisited,
        wish: response.sceneWish,
        show: response.scene.sceneScore,
        sortType: "score"
      };
    })
      .error(function (error) {
        console.log(error);
        $state.reload('login');
      });
  }

  if (searchHistoryNumI > 3) {
    $http({
      method: 'POST',
      url: "http://localhost:8080/server/scene/detail",
      params: {"sceneid": searchHistoryListId[3]},
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS, PUT, DELETE',
        'Access-Control-Allow-Headers': 'X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method',
        'Access-Control-Allow-Max-Age': '100'
      }
    }).success(function (response) {
      console.log(JSON.stringify(response));

      $scope.searchHistoryList[3] = {
        id: response.scene.sceneId,
        name: response.scene.sceneName,
        score: response.scene.sceneScore,
        star: response.scene.sceneFavor,
        come: response.scene.sceneVisited,
        wish: response.sceneWish,
        show: response.scene.sceneScore,
        sortType: "score"
      };
    })
      .error(function (error) {
        console.log(error);
        $state.reload('login');
      });
  }

  if (searchHistoryNumI > 4) {
    $http({
      method: 'POST',
      url: "http://localhost:8080/server/scene/detail",
      params: {"sceneid": searchHistoryListId[4]},
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS, PUT, DELETE',
        'Access-Control-Allow-Headers': 'X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method',
        'Access-Control-Allow-Max-Age': '100'
      }
    }).success(function (response) {
      console.log(JSON.stringify(response));

      $scope.searchHistoryList[4] = {
        id: response.scene.sceneId,
        name: response.scene.sceneName,
        score: response.scene.sceneScore,
        star: response.scene.sceneFavor,
        come: response.scene.sceneVisited,
        wish: response.sceneWish,
        show: response.scene.sceneScore,
        sortType: "score"
      };
    })
      .error(function (error) {
        console.log(error);
        $state.reload('login');
      });
  }

  if (searchHistoryNumI > 5) {
    $http({
      method: 'POST',
      url: "http://localhost:8080/server/scene/detail",
      params: {"sceneid": searchHistoryListId[5]},
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS, PUT, DELETE',
        'Access-Control-Allow-Headers': 'X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method',
        'Access-Control-Allow-Max-Age': '100'
      }
    }).success(function (response) {
      console.log(JSON.stringify(response));

      $scope.searchHistoryList[5] = {
        id: response.scene.sceneId,
        name: response.scene.sceneName,
        score: response.scene.sceneScore,
        star: response.scene.sceneFavor,
        come: response.scene.sceneVisited,
        wish: response.sceneWish,
        show: response.scene.sceneScore,
        sortType: "score"
      };
    })
      .error(function (error) {
        console.log(error);
        $state.reload('login');
      });
  }

  if (searchHistoryNumI > 6) {
    $http({
      method: 'POST',
      url: "http://localhost:8080/server/scene/detail",
      params: {"sceneid": searchHistoryListId[6]},
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS, PUT, DELETE',
        'Access-Control-Allow-Headers': 'X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method',
        'Access-Control-Allow-Max-Age': '100'
      }
    }).success(function (response) {
      console.log(JSON.stringify(response));

      $scope.searchHistoryList[6] = {
        id: response.scene.sceneId,
        name: response.scene.sceneName,
        score: response.scene.sceneScore,
        star: response.scene.sceneFavor,
        come: response.scene.sceneVisited,
        wish: response.sceneWish,
        show: response.scene.sceneScore,
        sortType: "score"
      };
    })
      .error(function (error) {
        console.log(error);
        $state.reload('login');
      });
  }

  if (searchHistoryNumI > 7) {
    $http({
      method: 'POST',
      url: "http://localhost:8080/server/scene/detail",
      params: {"sceneid": searchHistoryListId[7]},
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS, PUT, DELETE',
        'Access-Control-Allow-Headers': 'X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method',
        'Access-Control-Allow-Max-Age': '100'
      }
    }).success(function (response) {
      console.log(JSON.stringify(response));

      $scope.searchHistoryList[7] = {
        id: response.scene.sceneId,
        name: response.scene.sceneName,
        score: response.scene.sceneScore,
        star: response.scene.sceneFavor,
        come: response.scene.sceneVisited,
        wish: response.sceneWish,
        show: response.scene.sceneScore,
        sortType: "score"
      };
    })
      .error(function (error) {
        console.log(error);
        $state.reload('login');
      });
  }

  if (searchHistoryNumI > 8) {
    $http({
      method: 'POST',
      url: "http://localhost:8080/server/scene/detail",
      params: {"sceneid": searchHistoryListId[8]},
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS, PUT, DELETE',
        'Access-Control-Allow-Headers': 'X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method',
        'Access-Control-Allow-Max-Age': '100'
      }
    }).success(function (response) {
      console.log(JSON.stringify(response));

      $scope.searchHistoryList[8] = {
        id: response.scene.sceneId,
        name: response.scene.sceneName,
        score: response.scene.sceneScore,
        star: response.scene.sceneFavor,
        come: response.scene.sceneVisited,
        wish: response.sceneWish,
        show: response.scene.sceneScore,
        sortType: "score"
      };
    })
      .error(function (error) {
        console.log(error);
        $state.reload('login');
      });
  }

  if (searchHistoryNumI > 9) {
    $http({
      method: 'POST',
      url: "http://localhost:8080/server/scene/detail",
      params: {"sceneid": searchHistoryListId[9]},
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS, PUT, DELETE',
        'Access-Control-Allow-Headers': 'X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method',
        'Access-Control-Allow-Max-Age': '100'
      }
    }).success(function (response) {
      console.log(JSON.stringify(response));

      $scope.searchHistoryList[9] = {
        id: response.scene.sceneId,
        name: response.scene.sceneName,
        score: response.scene.sceneScore,
        star: response.scene.sceneFavor,
        come: response.scene.sceneVisited,
        wish: response.sceneWish,
        show: response.scene.sceneScore,
        sortType: "score"
      };
    })
      .error(function (error) {
        console.log(error);
        $state.reload('login');
      });
  }

});
